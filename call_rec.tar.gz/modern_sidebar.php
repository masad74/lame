<?php
if (!defined('VICI_BASE')) define('VICI_BASE', '/vicidial');
?>
<aside class="sidebar" id="appSidebar">
    <nav class="sidebar-nav">

        <div class="nav-group">
            <a href="<?php echo VICI_BASE ?>/admin.php" class="nav-item" title="Dashboard">
                <div class="nav-item-content">
                    <i class="bi bi-grid-fill"></i>
                    <span><?php echo _QXZ("Dashboard") ?></span>
                </div>
            </a>
        </div>

        <div class="nav-group">
            <a href="<?php echo VICI_BASE ?>/admin.php?ADD=999999" class="nav-item active" title="Reports">
                <div class="nav-item-content">
                    <i class="bi bi-file-earmark-text"></i>
                    <span><?php echo _QXZ("Reports") ?></span>
                </div>
            </a>
        </div>

        <!-- USERS -->
        <div class="nav-group">
            <div class="nav-item dropdown-toggle" onclick="toggleNavSubmenu(this)" title="Users">
                <div class="nav-item-content">
                    <i class="bi bi-person"></i>
                    <span><?php echo _QXZ("Users") ?></span>
                </div>
                <i class="bi bi-chevron-down submenu-arrow"></i>
            </div>
            <div class="nav-submenu">
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=0A">Show Users</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=1">Add A New User</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=1A">Copy User</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=550">Search For A User</a>
                <a href="<?php echo VICI_BASE ?>/user_stats.php">User Stats</a>
                <a href="<?php echo VICI_BASE ?>/user_status.php">User Status</a>
                <a href="<?php echo VICI_BASE ?>/AST_agent_time_sheet.php">Time Sheet</a>
            </div>
        </div>

        <!-- CAMPAIGNS -->
        <div class="nav-group">
            <div class="nav-item dropdown-toggle" onclick="toggleNavSubmenu(this)" title="Campaigns">
                <div class="nav-item-content">
                    <i class="bi bi-megaphone-fill"></i>
                    <span><?php echo _QXZ("Campaigns") ?></span>
                </div>
                <i class="bi bi-chevron-down submenu-arrow"></i>
            </div>
            <div class="nav-submenu">
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=10">Campaigns Main</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=32">Statuses</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=33">HotKeys</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=35">Lead Recycle</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=36">Auto-Alt Dial</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=39">List Mix</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=37">Pause Codes</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=301">Presets</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=302">AC-CID</a>
            </div>
        </div>

        <!-- LISTS -->
        <div class="nav-group">
            <div class="nav-item dropdown-toggle" onclick="toggleNavSubmenu(this)" title="Lists">
                <div class="nav-item-content">
                    <i class="bi bi-list-task"></i>
                    <span><?php echo _QXZ("Lists") ?></span>
                </div>
                <i class="bi bi-chevron-down submenu-arrow"></i>
            </div>
            <div class="nav-submenu">
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=100">Show Lists</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=111">Add A New List</a>
                <a href="<?php echo VICI_BASE ?>/admin_search_lead.php">Search For A Lead</a>
                <a href="<?php echo VICI_BASE ?>/admin_modify_lead.php">Add A New Lead</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=121">Add-Delete DNC Number</a>
                <a href="<?php echo VICI_BASE ?>/admin_listloader_fifth_gen.php">Load New Leads</a>
                <a href="<?php echo VICI_BASE ?>/admin_lists_custom.php">List Custom Fields</a>
                <a href="<?php echo VICI_BASE ?>/admin_lists_custom.php?action=COPY_FIELDS_FORM">Copy Custom Fields</a>
            </div>
        </div>

        <!-- SCRIPTS -->
        <div class="nav-group">
            <div class="nav-item dropdown-toggle" onclick="toggleNavSubmenu(this)" title="Scripts">
                <div class="nav-item-content">
                    <i class="bi bi-file-earmark-code"></i>
                    <span><?php echo _QXZ("Scripts") ?></span>
                </div>
                <i class="bi bi-chevron-down submenu-arrow"></i>
            </div>
            <div class="nav-submenu">
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=1000000">Show Scripts</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=1111111">Add A New Script</a>
            </div>
        </div>

        <!-- FILTERS -->
        <div class="nav-group">
            <div class="nav-item dropdown-toggle" onclick="toggleNavSubmenu(this)" title="Filters">
                <div class="nav-item-content">
                    <i class="bi bi-funnel"></i>
                    <span><?php echo _QXZ("Filters") ?></span>
                </div>
                <i class="bi bi-chevron-down submenu-arrow"></i>
            </div>
            <div class="nav-submenu">
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=10000000">Show Filters</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=11111111">Add A New Filter</a>
            </div>
        </div>

        <!-- INBOUND -->
        <div class="nav-group">
            <div class="nav-item dropdown-toggle" onclick="toggleNavSubmenu(this)" title="Inbound">
                <div class="nav-item-content">
                    <i class="bi bi-telephone"></i>
                    <span><?php echo _QXZ("Inbound") ?></span>
                </div>
                <i class="bi bi-chevron-down submenu-arrow"></i>
            </div>
            <div class="nav-submenu">
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=1001"><i class="bi bi-box-arrow-in-down"></i> Inbound</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=1000"><i class="bi bi-box-arrow-in-right"></i> Show In-Groups</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=1111" class="sub-nested">Add A New In-Group</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=1211" class="sub-nested">Copy In-Group</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=1300"><i class="bi bi-telephone"></i> Show DIDs</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=1311" class="sub-nested">Add A New DID</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=1411" class="sub-nested">Copy DID</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=1500"><i class="bi bi-menu-button-wide"></i> Show Call Menus</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=1511" class="sub-nested">Add A Call Menu</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=1611" class="sub-nested">Copy Call Menu</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=1700"><i class="bi bi-funnel"></i> Filter Phone Groups</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=1711" class="sub-nested">Add Filter Phone Group</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=171" class="sub-nested">Add-Delete FPG Number</a>
            </div>
        </div>

        <!-- USER GROUPS -->
        <div class="nav-group">
            <div class="nav-item dropdown-toggle" onclick="toggleNavSubmenu(this)" title="User Groups">
                <div class="nav-item-content">
                    <i class="bi bi-people"></i>
                    <span><?php echo _QXZ("User Groups") ?></span>
                </div>
                <i class="bi bi-chevron-down submenu-arrow"></i>
            </div>
            <div class="nav-submenu">
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=100000">Show User Groups</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=111111">Add A User Group</a>
                <a href="<?php echo VICI_BASE ?>/group_hourly_stats.php">Group Hourly Report</a>
                <a href="<?php echo VICI_BASE ?>/user_group_bulk_change.php">Bulk Group Change</a>
            </div>
        </div>

        <!-- REMOTE AGENTS -->
        <div class="nav-group">
            <div class="nav-item dropdown-toggle" onclick="toggleNavSubmenu(this)" title="Remote Agents">
                <div class="nav-item-content">
                    <i class="bi bi-headset"></i>
                    <span><?php echo _QXZ("Remote Agents") ?></span>
                </div>
                <i class="bi bi-chevron-down submenu-arrow"></i>
            </div>
            <div class="nav-submenu">
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=10000">Show Remote Agents</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=11111">Add Remote Agents</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=12000">Show Extension Groups</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=12111">Add Extension Group</a>
            </div>
        </div>

        <!-- ADMIN -->
        <div class="nav-group">
            <div class="nav-item dropdown-toggle" onclick="toggleNavSubmenu(this)" title="Admin">
                <div class="nav-item-content">
                    <i class="bi bi-gear"></i>
                    <span><?php echo _QXZ("Admin") ?></span>
                </div>
                <i class="bi bi-chevron-down submenu-arrow"></i>
            </div>
            <div class="nav-submenu">
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=999998"><i class="bi bi-gear"></i> Admin</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=100000000"><i class="bi bi-clock"></i> Call Times</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=130000000"><i class="bi bi-people"></i> Shifts</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=10000000000"><i class="bi bi-telephone"></i> Phones</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=130000000000"><i class="bi bi-file-earmark-text"></i> Templates</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=140000000000"><i class="bi bi-broadcast"></i> Carriers</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=100000000000"><i class="bi bi-hdd-network"></i> Servers</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=1000000000000"><i class="bi bi-headset"></i> Conferences</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=311111111111111"><i class="bi bi-gear"></i> System Settings</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=180000000000"><i class="bi bi-display"></i> Screen Labels</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=182000000000"><i class="bi bi-palette"></i> Screen Colors</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=321111111111115"><i class="bi bi-list-check"></i> System Statuses</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=193000000000"><i class="bi bi-collection"></i> Status Groups</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=196000000000"><i class="bi bi-card-heading"></i> CID Groups</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=170000000000"><i class="bi bi-voicemail"></i> Voicemail</a>
                <a href="<?php echo VICI_BASE ?>/admin_soundboard.php?ADD=162000000000"><i class="bi bi-music-note-beamed"></i> Audio Store</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=160000000000"><i class="bi bi-disc"></i> Music On Hold</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=197000000000"><i class="bi bi-chat-square-text"></i> VM Message Groups</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=192000000000"><i class="bi bi-box"></i> Settings Containers</a>
                <a href="<?php echo VICI_BASE ?>/admin.php?ADD=198000000000"><i class="bi bi-layers"></i> Queue Groups</a>
            </div>
        </div>

        <div class="fs-button-wrapper">
            <button type="button" onclick="toggleFullscreen()" class="fs-btn" title="Toggle Full Screen">
                <i class="bi bi-fullscreen"></i>
                <span class="fs-text">Full Screen</span>
            </button>
        </div>

        <div class="sos-button-wrapper">
            <button type="button" onclick="confirmSOS()" class="sos-btn" title="SOS - Emergency Logout">
                <i class="bi bi-shield-fill-exclamation sos-icon"></i>
                <span class="sos-text">SOS - Emergency Logout</span>
            </button>
        </div>

    </nav>
</aside>