<?php
# call_recordings_report_modern.php
#
# Custom modern-UI report: "Call Recordings Report" - Vc Export Call Report
# with Recording Filter. Displays a focused 13-column call + recording summary
# (outbound vicidial_log and inbound vicidial_closer_log calls, unioned)
# joined to their most recent recording_log entry, with pagination and
# CSV/XLSX/PDF export, following the same pattern as call_report_export_modern.php.
#
# Copyright (C) 2024  Matt Florell <vicidial@gmail.com>    LICENSE: AGPLv2
#

$startMS = microtime();

require("dbconnect_mysqli.php");
require("functions.php");

$PHP_AUTH_USER=(array_key_exists('PHP_AUTH_USER', $_SERVER) ? $_SERVER['PHP_AUTH_USER'] : "");
$PHP_AUTH_PW=(array_key_exists('PHP_AUTH_PW', $_SERVER) ? $_SERVER['PHP_AUTH_PW'] : "");
$PHP_SELF=$_SERVER['PHP_SELF'];
$PHP_SELF = preg_replace('/\.php.*/i','.php',$PHP_SELF);

if (isset($_GET["query_date"]))				{$query_date=$_GET["query_date"];}
	elseif (isset($_POST["query_date"]))	{$query_date=$_POST["query_date"];}
if (isset($_GET["query_hour"]))				{$query_hour=$_GET["query_hour"];}
	elseif (isset($_POST["query_hour"]))	{$query_hour=$_POST["query_hour"];}
if (isset($_GET["end_date"]))				{$end_date=$_GET["end_date"];}
	elseif (isset($_POST["end_date"]))		{$end_date=$_POST["end_date"];}
if (isset($_GET["end_hour"]))				{$end_hour=$_GET["end_hour"];}
	elseif (isset($_POST["end_hour"]))		{$end_hour=$_POST["end_hour"];}
if (isset($_GET["user"]))					{$user=$_GET["user"];}
	elseif (isset($_POST["user"]))			{$user=$_POST["user"];}
	else {$user="";}
if (isset($_GET["sort_dir"]))				{$sort_dir=$_GET["sort_dir"];}
	elseif (isset($_POST["sort_dir"]))		{$sort_dir=$_POST["sort_dir"];}
if (isset($_GET["campaign"]))				{$campaign=$_GET["campaign"];}
	elseif (isset($_POST["campaign"]))		{$campaign=$_POST["campaign"];}
	else {$campaign="";}
if (isset($_GET["user_group"]))				{$user_group=$_GET["user_group"];}
	elseif (isset($_POST["user_group"]))	{$user_group=$_POST["user_group"];}
	else {$user_group="";}
if (isset($_GET["recording_filter"]))			{$recording_filter=$_GET["recording_filter"];}
	elseif (isset($_POST["recording_filter"]))	{$recording_filter=$_POST["recording_filter"];}
	else {$recording_filter="ALL";}
if (isset($_GET["call_mode"]))				{$call_mode=$_GET["call_mode"];}
	elseif (isset($_POST["call_mode"]))	{$call_mode=$_POST["call_mode"];}
	else {$call_mode="ALL";}
if (isset($_GET["DB"]))						{$DB=$_GET["DB"];}
	elseif (isset($_POST["DB"]))			{$DB=$_POST["DB"];}
if (isset($_GET["run_export"]))				{$run_export=$_GET["run_export"];}
	elseif (isset($_POST["run_export"]))	{$run_export=$_POST["run_export"];}
	else {$run_export=0;}
if (isset($_GET["SUBMIT"]))					{$SUBMIT=$_GET["SUBMIT"];}
	elseif (isset($_POST["SUBMIT"]))		{$SUBMIT=$_POST["SUBMIT"];}
	else {$SUBMIT="";}
if (isset($_GET["search_archived_data"]))			{$search_archived_data=$_GET["search_archived_data"];}
	elseif (isset($_POST["search_archived_data"]))	{$search_archived_data=$_POST["search_archived_data"];}
	else {$search_archived_data="";}
if (isset($_GET["export_format"]))				{$export_format=$_GET["export_format"];}
	elseif (isset($_POST["export_format"]))	{$export_format=$_POST["export_format"];}
	else {$export_format="csv";}
if (!in_array($export_format, array('csv','xlsx','pdf'))) {$export_format='csv';}
if (isset($_GET["page"]))					{$page=$_GET["page"];}
	elseif (isset($_POST["page"]))			{$page=$_POST["page"];}
	else {$page=1;}
if (isset($_GET["per_page"]))				{$per_page=$_GET["per_page"];}
	elseif (isset($_POST["per_page"]))		{$per_page=$_POST["per_page"];}
	else {$per_page=50;}
if (isset($_GET["file_download"]))			{$file_download=$_GET["file_download"];}
	elseif (isset($_POST["file_download"]))	{$file_download=$_POST["file_download"];}
	else {$file_download=0;}

$DB=preg_replace("/[^0-9a-zA-Z]/","",$DB);

$NOW_DATE = date("Y-m-d");
$NOW_TIME = date("Y-m-d H:i:s");
$STARTtime = date("U");
if (!is_array($campaign)) {$campaign = array();}
if (!is_array($user_group)) {$user_group = array();}
if (!isset($query_date)) {$query_date = $NOW_DATE;}
if (!isset($end_date)) {$end_date = $NOW_DATE;}
if (!isset($query_hour)) {$query_hour = "00";}
if (!isset($end_hour)) {$end_hour = "23";}
if (!isset($sort_dir)) {$sort_dir = "asc";}
if ($page < 1) {$page = 1;}
if (!in_array($per_page, array(10,25,50,100,200,500))) {$per_page = 50;}
if (!in_array($recording_filter, array('ALL','HAS','NO'))) {$recording_filter = 'ALL';}
if (!in_array($call_mode, array('ALL','OUTBOUND','INBOUND'))) {$call_mode = 'ALL';}

// Real system pseudo-users that should never show up as an "agent" in this
# report -- VDAD is the predictive/auto-dial engine, VDCL is the closer/
# campaign system user for certain automated actions.
$EXCLUDED_SYSTEM_USERS_SQL = "'VDAD','VDCL'";
$export_headers=array(); $export_rows=array();

# NOTE: $report_name is intentionally kept as 'Call Export Report' (the same
# permission string used by call_report_export.php / call_report_export_modern.php)
# so this report reuses the same allowed_reports permission entry instead of
# requiring every user group to be reconfigured for a brand new report name.
$report_name = 'Call Export Report';
$report_display_title = 'Call Recordings Report';
$db_source = 'M';

#############################################
##### START SYSTEM_SETTINGS LOOKUP #####
$stmt = "SELECT use_non_latin,outbound_autodial_active,slave_db_server,reports_use_slave_db,enable_languages,language_method,log_recording_access,allow_web_debug FROM system_settings;";
$rslt=mysql_to_mysqli($stmt, $link);
$qm_conf_ct = mysqli_num_rows($rslt);
if ($qm_conf_ct > 0)
	{
	$row=mysqli_fetch_row($rslt);
	$non_latin =					$row[0];
	$outbound_autodial_active =		$row[1];
	$slave_db_server =				$row[2];
	$reports_use_slave_db =			$row[3];
	$SSenable_languages =			$row[4];
	$SSlanguage_method =			$row[5];
	$log_recording_access =		$row[6];
	$SSallow_web_debug =			$row[7];
	}
if ($SSallow_web_debug < 1 || !isset($DB)) {$DB=0;}
##### END SETTINGS LOOKUP #####
###########################################

$query_date = preg_replace('/[^\-0-9]/', '', $query_date);
$end_date = preg_replace('/[^\-0-9]/', '', $end_date);
$query_hour = preg_replace('/[^0-9]/', '', $query_hour);
$end_hour = preg_replace('/[^0-9]/', '', $end_hour);
$SUBMIT = preg_replace('/[^-_0-9a-zA-Z]/', '', $SUBMIT);
$run_export = preg_replace('/[^0-9]/', '', $run_export);
$search_archived_data = preg_replace('/[^-_0-9a-zA-Z]/', '', $search_archived_data);
$page = preg_replace('/[^0-9]/', '', $page);
$per_page = preg_replace('/[^0-9]/', '', $per_page);
$file_download = preg_replace('/[^0-9]/', '', $file_download);
$recording_filter = preg_replace('/[^A-Z]/', '', $recording_filter);
$query_time = $query_hour.":00:00";
$end_time = $end_hour.":59:59";

if ($non_latin < 1)
	{
	$PHP_AUTH_USER = preg_replace('/[^-_0-9a-zA-Z]/', '', $PHP_AUTH_USER);
	$PHP_AUTH_PW = preg_replace('/[^-_0-9a-zA-Z]/', '', $PHP_AUTH_PW);
	$user = preg_replace('/[^-_0-9a-zA-Z]/', '', $user);
	$sort_dir = preg_replace('/[^a-zA-Z]/', '', $sort_dir);
	}
else
	{
	$PHP_AUTH_USER = preg_replace('/[^-_0-9\p{L}]/u', '', $PHP_AUTH_USER);
	$PHP_AUTH_PW = preg_replace('/[^-_0-9\p{L}]/u', '', $PHP_AUTH_PW);
	$sort_dir = preg_replace('/[^\p{L}]/u', '', $sort_dir);
	}

switch ($sort_dir)
	{
	default:
	case "asc":	$asc = "checked"; $desc = ""; break;
	case "desc":	$asc = ""; $desc = "checked"; break;
	}

### ARCHIVED DATA CHECK CONFIGURATION
$archives_available = "N";
$log_tables_array = array("vicidial_log","vicidial_closer_log","recording_log");
for ($t=0; $t<count($log_tables_array); $t++)
	{
	$table_name = $log_tables_array[$t];
	$archive_table_name = use_archive_table($table_name);
	if ($archive_table_name != $table_name) {$archives_available = "Y";}
	}

if ($search_archived_data)
	{
	$vicidial_log_table = use_archive_table("vicidial_log");
	$vicidial_closer_log_table = use_archive_table("vicidial_closer_log");
	$recording_log_table = use_archive_table("recording_log");
	}
else
	{
	$vicidial_log_table = "vicidial_log";
	$vicidial_closer_log_table = "vicidial_closer_log";
	$recording_log_table = "recording_log";
	}
#############

$stmt="SELECT selected_language from vicidial_users where user='$PHP_AUTH_USER';";
if ($DB) {echo "|$stmt|\n";}
$rslt=mysql_to_mysqli($stmt, $link);
$sl_ct = mysqli_num_rows($rslt);
if ($sl_ct > 0)
	{
	$row=mysqli_fetch_row($rslt);
	$VUselected_language =		$row[0];
	}

$auth=0;
$reports_auth=0;
$admin_auth=0;
$auth_message = user_authorization($PHP_AUTH_USER,$PHP_AUTH_PW,'REPORTS',1,0);
if ( ($auth_message == 'GOOD') or ($auth_message == '2FA') )
	{
	$auth=1;
	if ($auth_message == '2FA')
		{
		header ("Content-type: text/html; charset=utf-8");
		echo _QXZ("Your session is expired").". <a href=\"admin.php\">"._QXZ("Click here to log in")."</a>.\n";
		exit;
		}
	}

if ($auth > 0)
	{
	$stmt="SELECT count(*) from vicidial_users where user='$PHP_AUTH_USER' and user_level > 7 and view_reports='1';";
	if ($DB) {echo "|$stmt|\n";}
	$rslt=mysql_to_mysqli($stmt, $link);
	$row=mysqli_fetch_row($rslt);
	$admin_auth=$row[0];

	$stmt="SELECT count(*) from vicidial_users where user='$PHP_AUTH_USER' and user_level > 6 and view_reports='1';";
	if ($DB) {echo "|$stmt|\n";}
	$rslt=mysql_to_mysqli($stmt, $link);
	$row=mysqli_fetch_row($rslt);
	$reports_auth=$row[0];

	if ($reports_auth < 1)
		{
		$VDdisplayMESSAGE = _QXZ("You are not allowed to view reports");
		Header ("Content-type: text/html; charset=utf-8");
		echo "$VDdisplayMESSAGE: |$PHP_AUTH_USER|$auth_message|\n";
		exit;
		}
	if ( ($reports_auth > 0) and ($admin_auth < 1) )
		{
		$ADD=999999;
		$reports_only_user=1;
		}
	}
else
	{
	$VDdisplayMESSAGE = _QXZ("Login incorrect, please try again");
	if ($auth_message == 'LOCK')
		{
		$VDdisplayMESSAGE = _QXZ("Too many login attempts, try again in 15 minutes");
		Header ("Content-type: text/html; charset=utf-8");
		echo "$VDdisplayMESSAGE: |$PHP_AUTH_USER|$auth_message|\n";
		exit;
		}
	if ($auth_message == 'IPBLOCK')
		{
		$VDdisplayMESSAGE = _QXZ("Your IP Address is not allowed") . ": $ip";
		Header ("Content-type: text/html; charset=utf-8");
		echo "$VDdisplayMESSAGE: |$PHP_AUTH_USER|$auth_message|\n";
		exit;
		}
	Header("WWW-Authenticate: Basic realm=\"CONTACT-CENTER-ADMIN\"");
	Header("HTTP/1.0 401 Unauthorized");
	echo "$VDdisplayMESSAGE: |$PHP_AUTH_USER|$PHP_AUTH_PW|$auth_message|\n";
	exit;
	}

$stmt="SELECT export_reports,user_group,admin_hide_phone_data,full_name from vicidial_users where user='$PHP_AUTH_USER';";
$rslt=mysql_to_mysqli($stmt, $link);
$row=mysqli_fetch_row($rslt);
$LOGexport_reports =			$row[0];
$LOGuser_group =				$row[1];
$LOGadmin_hide_phone_data =		$row[2];
$LOGfull_name =					$row[3];

if ($LOGexport_reports < 1)
	{
	Header ("Content-type: text/html; charset=utf-8");
	echo _QXZ("You do not have permissions for export reports").": |$PHP_AUTH_USER|\n";
	exit;
	}

##### BEGIN log visit to the vicidial_report_log table #####
$LOGip = getenv("REMOTE_ADDR");
$LOGbrowser = getenv("HTTP_USER_AGENT");
$LOGscript_name = getenv("SCRIPT_NAME");
$LOGserver_name = getenv("SERVER_NAME");
$LOGserver_port = getenv("SERVER_PORT");
$LOGrequest_uri = getenv("REQUEST_URI");
$LOGhttp_referer = getenv("HTTP_REFERER");
$LOGbrowser=preg_replace("/\'|\"|\\\\/","",$LOGbrowser);
$LOGrequest_uri=preg_replace("/\'|\"|\\\\/","",$LOGrequest_uri);
$LOGhttp_referer=preg_replace("/\'|\"|\\\\/","",$LOGhttp_referer);
if (preg_match("/443/i",$LOGserver_port)) {$HTTPprotocol = 'https://';}
  else {$HTTPprotocol = 'http://';}
if (($LOGserver_port == '80') or ($LOGserver_port == '443') ) {$LOGserver_port='';}
else {$LOGserver_port = ":$LOGserver_port";}
$LOGfull_url = "$HTTPprotocol$LOGserver_name$LOGserver_port$LOGrequest_uri";

$LOGhostname = php_uname('n');
if (strlen($LOGhostname)<1) {$LOGhostname='X';}
if (strlen($LOGserver_name)<1) {$LOGserver_name='X';}

$stmt="SELECT webserver_id FROM vicidial_webservers where webserver='$LOGserver_name' and hostname='$LOGhostname' LIMIT 1;";
$rslt=mysql_to_mysqli($stmt, $link);
if ($DB) {echo "$stmt\n";}
$webserver_id_ct = mysqli_num_rows($rslt);
if ($webserver_id_ct > 0)
	{
	$row=mysqli_fetch_row($rslt);
	$webserver_id = $row[0];
	}
else
	{
	$stmt="INSERT INTO vicidial_webservers (webserver,hostname) values('$LOGserver_name','$LOGhostname');";
	if ($DB) {echo "$stmt\n";}
	$rslt=mysql_to_mysqli($stmt, $link);
	$affected_rows = mysqli_affected_rows($link);
	$webserver_id = mysqli_insert_id($link);
	}

$stmt="INSERT INTO vicidial_report_log set event_date=NOW(), user='$PHP_AUTH_USER', ip_address='$LOGip', report_name='$report_name', browser='$LOGbrowser', referer='$LOGhttp_referer', notes='$LOGserver_name:$LOGserver_port $LOGscript_name |$query_date, $end_date, $file_download, $export_format|', url='$LOGfull_url', webserver='$webserver_id';";
if ($DB) {echo "|$stmt|\n";}
$rslt=mysql_to_mysqli($stmt, $link);
$report_log_id = mysqli_insert_id($link);
##### END log visit to the vicidial_report_log table #####

if ( (strlen($slave_db_server)>5) and (preg_match("/$report_name/",$reports_use_slave_db)) )
	{
	mysqli_close($link);
	$use_slave_server=1;
	$db_source = 'S';
	require("dbconnect_mysqli.php");
	}

$stmt="SELECT allowed_campaigns,allowed_reports,admin_viewable_groups from vicidial_user_groups where user_group='$LOGuser_group';";
if ($DB) {echo "|$stmt|\n";}
$rslt=mysql_to_mysqli($stmt, $link);
$row=mysqli_fetch_row($rslt);
$LOGallowed_campaigns =			$row[0];
$LOGallowed_reports =			$row[1];
$LOGadmin_viewable_groups =		$row[2];

if ( (!preg_match("/$report_name/",$LOGallowed_reports)) and (!preg_match("/ALL REPORTS/",$LOGallowed_reports)) )
	{
    Header("WWW-Authenticate: Basic realm=\"CONTACT-CENTER-ADMIN\"");
    Header("HTTP/1.0 401 Unauthorized");
    echo _QXZ("You are not allowed to view this report").": |$PHP_AUTH_USER|$report_name|\n";
    exit;
	}

$LOGallowed_campaignsSQL='';
$whereLOGallowed_campaignsSQL='';
$rawLOGallowed_campaignsSQL='';
if ( (!preg_match('/\-ALL/i', $LOGallowed_campaigns)) )
	{
	$rawLOGallowed_campaignsSQL = preg_replace("/ -/",'',$LOGallowed_campaigns);
	$rawLOGallowed_campaignsSQL = preg_replace("/ /","','",$rawLOGallowed_campaignsSQL);
	$LOGallowed_campaignsSQL = "and campaign_id IN('$rawLOGallowed_campaignsSQL')";
	$whereLOGallowed_campaignsSQL = "where campaign_id IN('$rawLOGallowed_campaignsSQL')";
	}
$regexLOGallowed_campaigns = " $LOGallowed_campaigns ";

$LOGadmin_viewable_groupsSQL='';
$whereLOGadmin_viewable_groupsSQL='';
$rawLOGadmin_viewable_groupsSQL='';
if ( (!preg_match('/\-\-ALL\-\-/i',$LOGadmin_viewable_groups)) and (strlen($LOGadmin_viewable_groups) > 3) )
	{
	$rawLOGadmin_viewable_groupsSQL = preg_replace("/ -/",'',$LOGadmin_viewable_groups);
	$rawLOGadmin_viewable_groupsSQL = preg_replace("/ /","','",$rawLOGadmin_viewable_groupsSQL);
	$LOGadmin_viewable_groupsSQL = "and user_group IN('---ALL---','$rawLOGadmin_viewable_groupsSQL')";
	$whereLOGadmin_viewable_groupsSQL = "where user_group IN('---ALL---','$rawLOGadmin_viewable_groupsSQL')";
	}

$i=0;
$campaign_string='|';
$campaign_ct = count($campaign);
while ($i < $campaign_ct)
	{
	$campaign[$i] = preg_replace('/[^-_0-9\p{L}]/u', '', $campaign[$i]);
	$campaign_string .= "$campaign[$i]|";
	$i++;
	}

$i=0;
$user_group_string='|';
$user_group_ct = count($user_group);
while ($i < $user_group_ct)
	{
	$user_group[$i] = preg_replace('/[^-_0-9\p{L}]/u', '', $user_group[$i]);
	$user_group_string .= "$user_group[$i]|";
	$i++;
	}

// Get campaigns for the Process dropdown (MODE=OUTBOUND source)
$stmt="select campaign_id from vicidial_campaigns $whereLOGallowed_campaignsSQL order by campaign_id;";
$rslt=mysql_to_mysqli($stmt, $link);
if ($DB) {echo "|$stmt\n";}
$campaigns_to_print = mysqli_num_rows($rslt);
$campaign_list=array();
$i=0;
$campaign_list[$i] = '---ALL---'; $i++;
while ($i < $campaigns_to_print+1)
	{
	$row=mysqli_fetch_row($rslt);
	$campaign_list[$i] = $row[0];
	$i++;
	}

// Get inbound groups for the Process dropdown (MODE=INBOUND source) -- an
// inbound call's campaign_id is really an inbound group_id (same convention
// used elsewhere in this codebase, e.g. the realtime dashboard's per-queue
// stats), so INBOUND mode must offer group_id values here, not campaign_id.
$whereLOGallowed_groupsSQL = (strlen($rawLOGallowed_campaignsSQL) > 0) ? "where group_id IN('$rawLOGallowed_campaignsSQL')" : '';
$stmt="select group_id from vicidial_inbound_groups $whereLOGallowed_groupsSQL order by group_id;";
$rslt=mysql_to_mysqli($stmt, $link);
if ($DB) {echo "|$stmt\n";}
$inbound_groups_to_print = mysqli_num_rows($rslt);
$inbound_group_list=array();
$i=0;
$inbound_group_list[$i] = '---ALL---'; $i++;
while ($i < $inbound_groups_to_print+1)
	{
	$row=mysqli_fetch_row($rslt);
	$inbound_group_list[$i] = $row[0];
	$i++;
	}

// Get user groups for dropdown
$stmt="select user_group from vicidial_user_groups $whereLOGadmin_viewable_groupsSQL order by user_group;";
$rslt=mysql_to_mysqli($stmt, $link);
if ($DB) {echo "|$stmt\n";}
$user_groups_to_print = mysqli_num_rows($rslt);
$user_group_list=array();
$i=0;
$user_group_list[$i] = '---ALL---'; $i++;
while ($i < $user_groups_to_print+1)
	{
	$row=mysqli_fetch_row($rslt);
	$user_group_list[$i] = $row[0];
	$i++;
	}

// Real "location" pills for the topbar (Kochi/Bhubaneswar/Chandigarh/etc. are
// not fixed labels -- they are actual vicidial_user_groups rows, same real
# source + permission scoping as the User Groups filter above, just surfaced
# as quick one-click shortcuts instead of the multi-select).
$stmt="select user_group, group_name from vicidial_user_groups $whereLOGadmin_viewable_groupsSQL order by group_name;";
$rslt=mysql_to_mysqli($stmt, $link);
if ($DB) {echo "|$stmt\n";}
$location_rows=array();
while ($row=mysqli_fetch_row($rslt))
	{
	$location_rows[] = array('user_group' => $row[0], 'group_name' => (strlen($row[1])>0 ? $row[1] : $row[0]));
	}

// "Active" location = the single real user_group currently selected via the
// filter (matches the pill the user actually clicked); anything else (no
// selection, ALL, or more than one selected) falls back to "All Location".
$active_location = 'all';
$selected_user_groups_real = array();
foreach ($user_group as $ug) {if (!preg_match('/^---/',$ug)) {$selected_user_groups_real[] = $ug;}}
if (count($selected_user_groups_real) == 1) {$active_location = $selected_user_groups_real[0];}

// Function to build a URL carrying all current filters + pagination
function build_recordings_url($base, $campaign, $user_group, $user, $sort_dir, $search_archived_data, $recording_filter, $query_date, $end_date, $query_hour, $end_hour, $page=null, $per_page=null, $file_download=null, $export_format=null)
	{
	global $call_mode;
	$url = $base."?query_date=$query_date&end_date=$end_date&query_hour=$query_hour&end_hour=$end_hour&DB=0";
	$url .= "&user=$user&sort_dir=$sort_dir&recording_filter=$recording_filter&call_mode=$call_mode";
	if ($search_archived_data) {$url .= "&search_archived_data=$search_archived_data";}
	foreach ($campaign as $c) {if (!preg_match('/^---/',$c)) {$url .= "&campaign[]=$c";}}
	foreach ($user_group as $ug) {if (!preg_match('/^---/',$ug)) {$url .= "&user_group[]=$ug";}}
	if ($page !== null) {$url .= "&page=$page";}
	if ($per_page !== null) {$url .= "&per_page=$per_page";}
	if ($file_download !== null) {$url .= "&file_download=$file_download";}
	if ($export_format !== null) {$url .= "&export_format=$export_format";}
	$url .= "&run_export=1";
	return $url;
	}

$base_url = build_recordings_url($PHP_SELF, $campaign, $user_group, $user, $sort_dir, $search_archived_data, $recording_filter, $query_date, $end_date, $query_hour, $end_hour, null, null, null, null);
$download_link = build_recordings_url($PHP_SELF, $campaign, $user_group, $user, $sort_dir, $search_archived_data, $recording_filter, $query_date, $end_date, $query_hour, $end_hour, null, null, 1, null);

$NWB = "<IMG SRC=\"help.gif\" onClick=\"FillAndShowHelpDiv(event, '";
$NWE = "')\" WIDTH=20 HEIGHT=20 BORDER=0 ALT=\"HELP\" ALIGN=TOP>";

if ($file_download == 1) {$run_export = 1;}

// The entire page shell/filter panel below only makes sense for the on-screen view.
// For file downloads we must not echo any HTML before the header()/file content further
// down, or the CSV/XLSX/PDF gets the whole page prepended to it (and header() silently
// fails because output has already started).
if ($file_download < 1)
	{
	?>

<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<meta name="robots" content="none" />
	<meta name="copyright" content="© 2026 ViciDial Group" />
	<meta name="author" content="ViciDial Group" />

	<link href="css/bootstrap.min.css" rel="stylesheet" />
	<link href="css/bootstrap-icons.css" rel="stylesheet" />
	<link href="css/select2.min.css" rel="stylesheet" />
	<link href="css/daterangepicker.css" rel="stylesheet" />
	<link rel="stylesheet" href="css/style.css" />
	<meta http-equiv="Pragma" content="no-cache" />
	<meta http-equiv="Expires" content="-1" />
	<meta http-equiv="CACHE-CONTROL" content="NO-CACHE" />
	<title><?php echo _QXZ($report_display_title) ?> | IFTAS Samvad</title>
</head>

<body>
	<?php
	// admin_header.php still runs for its real session/permission/color-lookup
	// side effects ($SSframe_background, $selected_logo, $ADMIN, etc.) that the
	// rest of this file and other includes rely on -- short_header+no_header
	// just suppresses its own legacy visual HTML output, which this modern
	// topbar/sidebar replaces.
	$short_header=1;
	$no_header=1;
	require("admin_header.php");
	?>
	<div id='HelpDisplayDiv' class='help_info d-none'></div>

	<div class="app-container">
		<!-- FULL WIDTH TOPBAR -->
		<header class="topbar">
			<div class="topbar-left">
				<button class="sidebar-toggle-btn" id="sidebarToggleBtn" onclick="toggleSidebar()"
					title="Toggle Sidebar" aria-label="Toggle Sidebar">
					<i class="bi bi-list"></i>
				</button>
				<button class="exit-fullscreen-btn" id="exitFullscreenBtn" onclick="toggleFullscreen()"
					title="Exit Fullscreen" aria-label="Exit Fullscreen">
					<i class="bi bi-fullscreen-exit"></i>
				</button>

				<a href="admin.php" class="brand" title="Dashboard Home">
					<div class="brand-logo">
						<img src="images/vicidial_admin_web_logo.png" alt="ViciDial" class="brand-logo-img" />
					</div>
				</a>

				<div class="header-divider"></div>

				<div class="header-title-block">
					<div class="header-title-row">
						<h1 class="header-title"><?php echo _QXZ("System & Analytical Reports") ?></h1>
					</div>
					<div class="header-subtitle"><?php echo _QXZ($report_display_title) ?></div>
				</div>

				<div class="location-filter-pills" id="topLocationFilters">
					<a class="loc-pill-btn<?php echo ($active_location=='all')?' active':'' ?>"
						href="<?php echo htmlspecialchars(build_recordings_url($PHP_SELF,$campaign,array(),$user,$sort_dir,$search_archived_data,$recording_filter,$query_date,$end_date,$query_hour,$end_hour,1,$per_page,null,null)) ?>"
						title="All Locations">
						<i class="bi bi-globe2"></i>
						<span>All Location</span>
					</a>
					<?php foreach ($location_rows as $loc): ?>
					<a class="loc-pill-btn<?php echo ($active_location==$loc['user_group'])?' active':'' ?>"
						href="<?php echo htmlspecialchars(build_recordings_url($PHP_SELF,$campaign,array($loc['user_group']),$user,$sort_dir,$search_archived_data,$recording_filter,$query_date,$end_date,$query_hour,$end_hour,1,$per_page,null,null)) ?>"
						title="<?php echo htmlspecialchars($loc['group_name']) ?>">
						<i class="bi bi-geo-alt-fill"></i>
						<span><?php echo htmlspecialchars($loc['group_name']) ?></span>
					</a>
					<?php endforeach; ?>
				</div>
			</div>

			<div class="topbar-right">
				<div class="loc-mobile-toggle-wrap" id="topLocMobileWrap">
					<button type="button" class="topbar-icon-btn loc-mobile-toggle-btn" id="locMobileToggleBtn"
						onclick="toggleTopLocationMenu(event)" title="Location Filter" aria-label="Filter Locations">
						<i class="bi bi-geo-alt-fill"></i>
					</button>
					<div class="loc-dropdown-mobile" id="topLocMobileDropdown">
						<div class="loc-dropdown-mobile-header">
							<i class="bi bi-geo-alt-fill"></i>
							<span>Filter By Location</span>
						</div>
						<a class="loc-mobile-item<?php echo ($active_location=='all')?' active':'' ?>"
							href="<?php echo htmlspecialchars(build_recordings_url($PHP_SELF,$campaign,array(),$user,$sort_dir,$search_archived_data,$recording_filter,$query_date,$end_date,$query_hour,$end_hour,1,$per_page,null,null)) ?>">
							<div class="loc-item-left">
								<i class="bi bi-globe2"></i>
								<span>All Location</span>
							</div>
							<i class="bi bi-check2 check-icon"></i>
						</a>
						<?php foreach ($location_rows as $loc): ?>
						<a class="loc-mobile-item<?php echo ($active_location==$loc['user_group'])?' active':'' ?>"
							href="<?php echo htmlspecialchars(build_recordings_url($PHP_SELF,$campaign,array($loc['user_group']),$user,$sort_dir,$search_archived_data,$recording_filter,$query_date,$end_date,$query_hour,$end_hour,1,$per_page,null,null)) ?>">
							<div class="loc-item-left">
								<i class="bi bi-geo-alt-fill"></i>
								<span><?php echo htmlspecialchars($loc['group_name']) ?></span>
							</div>
							<i class="bi bi-check2 check-icon"></i>
						</a>
						<?php endforeach; ?>
					</div>
				</div>

				<div class="topbar-clock-block">
					<div class="clock-time-row">
						<span id="headerLiveTime">--:--:--</span>
						<span class="live-pulse-badge"><span class="pulse-dot"></span>LIVE</span>
					</div>
					<div class="clock-date-row" id="headerLiveDate"></div>
				</div>

				<div class="user-dropdown">
					<button type="button" class="user-profile-btn" onclick="toggleUserDropdown(event)"
						aria-expanded="false" title="User Menu">
						<div class="user-avatar">
							<i class="bi bi-person-fill"></i>
						</div>
						<div class="user-profile-info">
							<span class="user-name"><?php echo htmlspecialchars(strlen($LOGfull_name) > 0 ? $LOGfull_name : $PHP_AUTH_USER) ?></span>
							<span class="user-role"><?php echo ($admin_auth > 0) ? _QXZ("Administrator") : _QXZ("Reports User") ?></span>
						</div>
						<i class="bi bi-chevron-down user-chevron"></i>
					</button>
					<div class="user-menu-dropdown" id="userMenuDropdown">
						<a href="admin.php" class="user-menu-item">
							<i class="bi bi-house-door"></i>
							<span><?php echo _QXZ("Dashboard Home") ?></span>
						</a>
						<a href="admin.php?ADD=999999" class="user-menu-item active">
							<i class="bi bi-file-earmark-text"></i>
							<span><?php echo _QXZ("Reports") ?></span>
						</a>
						<a href="timeclock_status.php" class="user-menu-item">
							<i class="bi bi-clock-history"></i>
							<span><?php echo _QXZ("Timeclock") ?></span>
						</a>
						<a href="manager_chat_interface.php" class="user-menu-item">
							<i class="bi bi-chat-dots"></i>
							<span><?php echo _QXZ("Chat") ?></span>
						</a>
						<div class="user-menu-divider"></div>
						<a href="admin.php?force_logout=1" class="user-menu-item logout-item">
							<i class="bi bi-box-arrow-right"></i>
							<span><?php echo _QXZ("Logout") ?></span>
						</a>
					</div>
				</div>
			</div>
		</header>

		<!-- APP BODY WRAPPER (SIDEBAR ON LEFT + MAIN CONTENT ON RIGHT) -->
		<div class="app-body">
			<div class="sidebar-backdrop" onclick="closeMobileSidebar()"></div>

			<?php require('modern_sidebar.php'); ?>

			<!-- MAIN CONTENT AREA -->
			<main class="main-content">
				<div id="agent_status_stats" class="content-body report-content-body">
					<!-- PAGE HEADER & BREADCRUMB -->
					<div class="page-header">
						<div class="page-header-title-wrap">
							<nav aria-label="breadcrumb">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="admin.php"><i class="bi bi-house-door me-1"></i><?php echo _QXZ("Dashboard") ?></a></li>
									<li class="breadcrumb-item"><a href="admin.php?ADD=999999"><?php echo _QXZ("Reports") ?></a></li>
									<li class="breadcrumb-item active" aria-current="page"><?php echo _QXZ($report_display_title) ?></li>
								</ol>
							</nav>
						</div>
					</div>

					<!-- ADVANCED FILTER & SEARCH ACCORDION -->
					<div class="user-filter-accordion" id="callFilterAccordion">
						<div class="user-filter-accordion-header" onclick="toggleCallFiltersAccordion()" role="button"
							tabindex="0" title="Click to expand/collapse filters">
							<div class="d-flex align-items-center gap-2">
								<i class="bi bi-funnel-fill text-primary"></i>
								<span class="user-filter-accordion-title"><?php echo _QXZ("Search & Filter Recordings") ?></span>
							</div>
							<div class="d-flex align-items-center gap-2">
								<button type="button"
									class="btn btn-sm btn-link text-decoration-none p-0 text-secondary d-flex align-items-center gap-1 filter-accordion-toggle-btn">
									<span id="callFilterAccordionToggleText"><?php echo _QXZ("Hide Filters") ?></span>
									<i class="bi bi-chevron-up" id="callFilterAccordionChevron"></i>
								</button>
							</div>
						</div>
						<div class="user-filter-accordion-body" id="callFilterAccordionBody">
							<form action="<?php echo htmlspecialchars($PHP_SELF) ?>" method="GET" name="vicidial_report" id="vicidial_report">
								<input type="hidden" name="DB" value="<?php echo (int)$DB ?>">
								<input type="hidden" name="run_export" value="1">
								<input type="hidden" name="page" value="1">
								<input type="hidden" name="per_page" value="<?php echo (int)$per_page ?>">

								<div class="row g-3">
									<!-- 1. Unified Date & Time Range Selector -->
									<div class="col-12 col-md-6 col-lg-4">
										<label class="form-label form-label-custom" for="datetime_range">
											<i class="bi bi-calendar-range me-1 text-primary"></i> <?php echo _QXZ("Date & Time Range") ?>
										</label>
										<div class="input-group input-group-sm">
											<span class="input-group-text bg-light text-primary border-end-0"><i class="bi bi-calendar-week"></i></span>
											<input type="text" class="form-control form-control-sm form-control-custom border-start-0 input-daterange-box"
												id="datetime_range" placeholder="Select Start &amp; End Date/Time" readonly>
										</div>
										<input type="hidden" name="query_date" id="query_date" value="<?php echo htmlspecialchars($query_date) ?>">
										<input type="hidden" name="query_hour" id="query_hour" value="<?php echo htmlspecialchars($query_hour) ?>">
										<input type="hidden" name="end_date" id="end_date" value="<?php echo htmlspecialchars($end_date) ?>">
										<input type="hidden" name="end_hour" id="end_hour" value="<?php echo htmlspecialchars($end_hour) ?>">
									</div>

									<!-- 1b. Call Mode -->
									<div class="col-12 col-md-6 col-lg-2">
										<label class="form-label form-label-custom">
											<i class="bi bi-arrow-left-right me-1 text-primary"></i> <?php echo _QXZ("Call Mode") ?>
										</label>
										<select name="call_mode" id="call_mode" class="form-select form-select-sm form-select-custom" onchange="this.form.submit()">
											<option value="ALL"<?php echo ($call_mode=='ALL')?' selected':'' ?>><?php echo _QXZ("ALL") ?></option>
											<option value="OUTBOUND"<?php echo ($call_mode=='OUTBOUND')?' selected':'' ?>><?php echo _QXZ("OUTBOUND") ?></option>
											<option value="INBOUND"<?php echo ($call_mode=='INBOUND')?' selected':'' ?>><?php echo _QXZ("INBOUND") ?></option>
										</select>
									</div>

									<!-- 2. Process (Campaigns / Inbound Groups, depending on Call Mode) Multi-Select -->
									<div class="col-12 col-md-6 col-lg-4">
										<label class="form-label form-label-custom">
											<i class="bi bi-megaphone me-1 text-primary"></i> <?php echo _QXZ("Process") ?>
										</label>
										<select name="campaign[]" id="campaign_select" class="form-select form-select-sm select2-multiple" multiple="multiple">
											<?php
											if ($call_mode == 'OUTBOUND') {
												for ($o = 0; $o <= $campaigns_to_print; $o++) {
													$csel = preg_match("/\|".preg_quote($campaign_list[$o], '/')."\|/", $campaign_string) ? " selected" : "";
													echo "<option value=\"".htmlspecialchars($campaign_list[$o])."\"$csel>"._QXZ($campaign_list[$o])."</option>\n";
												}
											} elseif ($call_mode == 'INBOUND') {
												for ($o = 0; $o <= $inbound_groups_to_print; $o++) {
													$gsel = preg_match("/\|".preg_quote($inbound_group_list[$o], '/')."\|/", $campaign_string) ? " selected" : "";
													echo "<option value=\"".htmlspecialchars($inbound_group_list[$o])."\"$gsel>"._QXZ($inbound_group_list[$o])."</option>\n";
												}
											} else {
												echo "<option value=\"---ALL---\"".(preg_match("/\|---ALL---\|/", $campaign_string) ? " selected" : "").">"._QXZ('---ALL---')."</option>\n";
												echo "<optgroup label=\""._QXZ("Campaigns (Outbound)")."\">\n";
												for ($o = 1; $o <= $campaigns_to_print; $o++) {
													$csel = preg_match("/\|".preg_quote($campaign_list[$o], '/')."\|/", $campaign_string) ? " selected" : "";
													echo "<option value=\"".htmlspecialchars($campaign_list[$o])."\"$csel>"._QXZ($campaign_list[$o])."</option>\n";
												}
												echo "</optgroup>\n";
												echo "<optgroup label=\""._QXZ("Inbound Groups")."\">\n";
												for ($o = 1; $o <= $inbound_groups_to_print; $o++) {
													$gsel = preg_match("/\|".preg_quote($inbound_group_list[$o], '/')."\|/", $campaign_string) ? " selected" : "";
													echo "<option value=\"".htmlspecialchars($inbound_group_list[$o])."\"$gsel>"._QXZ($inbound_group_list[$o])."</option>\n";
												}
												echo "</optgroup>\n";
											}
											?>
										</select>
									</div>

									<!-- 3. User Groups Multi-Select -->
									<div class="col-12 col-md-6 col-lg-4">
										<label class="form-label form-label-custom">
											<i class="bi bi-people me-1 text-primary"></i> <?php echo _QXZ("User Groups") ?>
										</label>
										<select name="user_group[]" id="user_group_select" class="form-select form-select-sm select2-multiple" multiple="multiple">
											<?php
											for ($o = 0; $o <= $user_groups_to_print; $o++) {
												$usel = preg_match("/\|".preg_quote($user_group_list[$o], '/')."\|/", $user_group_string) ? " selected" : "";
												echo "<option value=\"".htmlspecialchars($user_group_list[$o])."\"$usel>"._QXZ($user_group_list[$o])."</option>\n";
											}
											?>
										</select>
									</div>

									<!-- 4. Agent ID -->
									<div class="col-12 col-md-4 col-lg-3">
										<label class="form-label form-label-custom">
											<i class="bi bi-person-badge me-1 text-primary"></i> <?php echo _QXZ("Agent ID") ?>
										</label>
										<input type="text" class="form-control form-control-sm form-control-custom"
											name="user" id="user" placeholder="e.g. 1001, VDAD" maxlength="20" value="<?php echo htmlspecialchars($user) ?>">
									</div>

									<!-- 5. Recording Filter -->
									<div class="col-12 col-md-4 col-lg-3">
										<label class="form-label form-label-custom">
											<i class="bi bi-mic me-1 text-primary"></i> <?php echo _QXZ("Recording Filter") ?>
										</label>
										<select name="recording_filter" id="recording_filter" class="form-select form-select-sm form-select-custom">
											<option value="ALL"<?php echo ($recording_filter=='ALL')?' selected':'' ?>><?php echo _QXZ("All Calls") ?></option>
											<option value="HAS"<?php echo ($recording_filter=='HAS')?' selected':'' ?>><?php echo _QXZ("Has Recording") ?></option>
											<option value="NO"<?php echo ($recording_filter=='NO')?' selected':'' ?>><?php echo _QXZ("No Recording") ?></option>
										</select>
									</div>

									<!-- 6. Sort Order & Archived Data -->
									<div class="col-12 col-md-4 col-lg-3">
										<label class="form-label form-label-custom">
											<i class="bi bi-sort-numeric-down me-1 text-primary"></i> <?php echo _QXZ("Sort Order & Archive") ?>
										</label>
										<div class="d-flex align-items-center gap-3 mt-1">
											<div class="form-check form-check-inline m-0">
												<input class="form-check-input" type="radio" value="asc" name="sort_dir" id="sort_asc" <?php echo $asc ?>>
												<label class="form-check-label form-check-label-custom" for="sort_asc"><?php echo _QXZ("Ascending") ?></label>
											</div>
											<div class="form-check form-check-inline m-0">
												<input class="form-check-input" type="radio" value="desc" name="sort_dir" id="sort_desc" <?php echo $desc ?>>
												<label class="form-check-label form-check-label-custom" for="sort_desc"><?php echo _QXZ("Descending") ?></label>
											</div>
										</div>
										<?php if ($archives_available == "Y") { ?>
										<div class="form-check mt-1">
											<input class="form-check-input" type="checkbox" name="search_archived_data" id="search_archived_data" value="checked" <?php echo $search_archived_data ?>>
											<label class="form-check-label text-muted small" for="search_archived_data"><?php echo _QXZ("Search archived data") ?></label>
										</div>
										<?php } ?>
									</div>

									<!-- 7. Submit & Reset Actions -->
									<div class="col-12 col-md-12 col-lg-3 d-flex align-items-end">
										<div class="d-flex align-items-center gap-2 w-100 pb-1">
											<button type="submit" name="SUBMIT" value="SUBMIT" class="btn-add-user flex-grow-1 justify-content-center btn-submit-filter">
												<i class="bi bi-funnel-fill"></i> <span><?php echo _QXZ("Apply Filter") ?></span>
											</button>
											<a href="<?php echo htmlspecialchars($PHP_SELF) ?>" class="btn-reset-filters btn-reset-filter-custom" title="Reset Filters">
												<i class="bi bi-arrow-counterclockwise"></i> <span><?php echo _QXZ("Reset") ?></span>
											</a>
										</div>
									</div>
								</div>
							</form>
						</div>
					</div>
	<?php
	}

##### START RUN THE EXPORT AND DISPLAY DATA #####
if ($run_export > 0)
	{
	// Build campaign (Process) SQL
	$campaign_SQL = "";
	if (!preg_match('/\-\-ALL\-\-/',$campaign_string))
		{
		$temp_sql = "";
		foreach ($campaign as $c) {if (!preg_match('/\-\-ALL\-\-/',$c)) {$temp_sql .= "'$c',";}}
		if (strlen($temp_sql) > 0)
			{
			$temp_sql = preg_replace('/,$/i', '',$temp_sql);
			$campaign_SQL = "and calls.campaign_id IN($temp_sql)";
			}
		}

	// Build user_group SQL
	$user_group_SQL = "";
	if (!preg_match('/\-\-ALL\-\-/',$user_group_string))
		{
		$temp_sql = "";
		foreach ($user_group as $ug) {if (!preg_match('/\-\-ALL\-\-/',$ug)) {$temp_sql .= "'$ug',";}}
		if (strlen($temp_sql) > 0)
			{
			$temp_sql = preg_replace('/,$/i', '',$temp_sql);
			$user_group_SQL = "and calls.user_group IN($temp_sql)";
			}
		}

	// Build agent (user) SQL
	$user_SQL = "";
	if (strlen($user) > 0) {$user_SQL = "and calls.user='$user'";}

	// Build recording filter SQL
	$recording_SQL = "";
	if ($recording_filter == 'HAS') {$recording_SQL = "and rl.filename is not null and rl.filename != ''";}
	if ($recording_filter == 'NO') {$recording_SQL = "and (rl.filename is null or rl.filename = '')";}

	$query_date_BEGIN = "$query_date $query_time";
	$query_date_END = "$end_date $end_time";

	// MODE=OUTBOUND/INBOUND narrows to just that one real log table instead of
	// the union of both; MODE=ALL keeps unioning them like before.
	$calls_fields_sql = "call_type, uniqueid, lead_id, campaign_id, user, user_group, phone_number, call_date, length_in_sec";
	if ($call_mode == 'OUTBOUND')
		{
		$calls_inner_sql = "(SELECT 'OUTBOUND' as call_type, uniqueid, lead_id, campaign_id, user, user_group, phone_number, call_date, length_in_sec
			FROM ".$vicidial_log_table."
			WHERE call_date >= '$query_date_BEGIN' and call_date <= '$query_date_END')";
		}
	elseif ($call_mode == 'INBOUND')
		{
		$calls_inner_sql = "(SELECT 'INBOUND' as call_type, uniqueid, lead_id, campaign_id, user, user_group, phone_number, call_date, length_in_sec
			FROM ".$vicidial_closer_log_table."
			WHERE call_date >= '$query_date_BEGIN' and call_date <= '$query_date_END')";
		}
	else
		{
		$calls_inner_sql = "(SELECT 'OUTBOUND' as call_type, uniqueid, lead_id, campaign_id, user, user_group, phone_number, call_date, length_in_sec
				FROM ".$vicidial_log_table."
				WHERE call_date >= '$query_date_BEGIN' and call_date <= '$query_date_END'
			UNION ALL
			SELECT 'INBOUND' as call_type, uniqueid, lead_id, campaign_id, user, user_group, phone_number, call_date, length_in_sec
				FROM ".$vicidial_closer_log_table."
				WHERE call_date >= '$query_date_BEGIN' and call_date <= '$query_date_END')";
		}

	// Prefer the exact per-call match (recording_log.vicidial_id = the call's
	# own uniqueid). Some recordings never get that column linked correctly
	# (seen for real leads whose recording still exists), so fall back to
	# matching by lead_id when the uniqueid match comes up empty -- guarded
	# to lead_id > 0 so leadless calls (lead_id 0/blank) never collide with
	# each other and pick up an unrelated lead's recording.
	$calls_union_sql = "
		$calls_inner_sql calls
		LEFT JOIN (SELECT vicidial_id, MAX(recording_id) as max_rec_id FROM ".$recording_log_table." GROUP BY vicidial_id) rlm_id
			ON rlm_id.vicidial_id = calls.uniqueid
		LEFT JOIN (SELECT lead_id, MAX(recording_id) as max_rec_id FROM ".$recording_log_table." WHERE lead_id > 0 GROUP BY lead_id) rlm_lead
			ON rlm_lead.lead_id = calls.lead_id
		LEFT JOIN ".$recording_log_table." rl ON rl.recording_id = COALESCE(rlm_id.max_rec_id, rlm_lead.max_rec_id)
		WHERE 1=1 $campaign_SQL $user_group_SQL $user_SQL $recording_SQL and calls.user NOT IN($EXCLUDED_SYSTEM_USERS_SQL)";

	// First get total count
	$count_stmt = "SELECT COUNT(*) FROM ".$calls_union_sql;
	$count_rslt = mysql_to_mysqli($count_stmt, $link);
	if ($DB) {echo "$count_stmt\n";}
	$count_row = mysqli_fetch_row($count_rslt);
	$total_records = $count_row[0];

	// Calculate pagination
	$total_pages = ceil($total_records / $per_page);
	if ($page > $total_pages && $total_pages > 0) {$page = $total_pages;}
	if ($page < 1) {$page = 1;}
	$offset = ($page - 1) * $per_page;

	$select_cols = "calls.call_type, calls.user, calls.campaign_id, calls.phone_number, calls.call_date, calls.length_in_sec, rl.filename, rl.location, rl.recording_id, calls.lead_id";

	// Get paginated data
	$stmt = "SELECT ".$select_cols." FROM ".$calls_union_sql." ORDER BY calls.call_date $sort_dir LIMIT $offset, $per_page";
	$rslt=mysql_to_mysqli($stmt, $link);
	if ($DB) {echo "$stmt\n";}
	$rows_to_print = mysqli_num_rows($rslt);

	if ($rows_to_print < 1 && $total_records > 0)
		{
		$page = 1;
		$offset = 0;
		$stmt = "SELECT ".$select_cols." FROM ".$calls_union_sql." ORDER BY calls.call_date $sort_dir LIMIT 0, $per_page";
		$rslt=mysql_to_mysqli($stmt, $link);
		$rows_to_print = mysqli_num_rows($rslt);
		}

	if ($rows_to_print < 1 && $total_records < 1)
		{
		if ($file_download < 1)
			{
			echo "<div class=\"user-table-card\"><div class=\"text-center text-muted py-5\">";
			echo "<i class=\"bi bi-mic-mute fs-1 d-block mb-2\"></i>";
			echo _QXZ("There are no calls during this time period for these parameters");
			echo "</div></div>\n";
			}
		}
	else
		{
		$report_rows=array();

		while ($row=mysqli_fetch_row($rslt))
			{
			$call_type =		$row[0];
			$agent_id =		$row[1];
			$campaign_id =	$row[2];
			$phone_number =	$row[3];
			$call_date =		$row[4];
			$length_in_sec =	$row[5];
			$rec_filename =	$row[6];
			$rec_location =	$row[7];
			$rec_recording_id =	$row[8];
			$rec_lead_id =	$row[9];

			if ($LOGadmin_hide_phone_data != '0')
				{
				if (strlen($phone_number) > 0)
					{
					if ($LOGadmin_hide_phone_data == '4_DIGITS') {$phone_number = str_repeat("X",(strlen($phone_number)-4)).substr($phone_number,-4,4);}
					elseif ($LOGadmin_hide_phone_data == '3_DIGITS') {$phone_number = str_repeat("X",(strlen($phone_number)-3)).substr($phone_number,-3,3);}
					elseif ($LOGadmin_hide_phone_data == '2_DIGITS') {$phone_number = str_repeat("X",(strlen($phone_number)-2)).substr($phone_number,-2,2);}
					else {$phone_number = preg_replace("/./",'X',$phone_number);}
					}
				}

			$start_time_display = date('n/j/y G:i:s', strtotime($call_date));
			$talk_duration = sec_convert($length_in_sec,'H');
			$recording_status = ( (strlen($rec_filename) > 0) ? _QXZ("Available") : _QXZ("Not Available") );
			$rec_filename_display = (strlen($rec_filename) > 0) ? $rec_filename : '-';
			$rec_location_display = (strlen($rec_location) > 0) ? $rec_location : '-';

			// Playback opens the exact same path shown in the Recording Path
			// column (rl.location) in a small popup window -- recordings are
			// stored on an external server, so that raw location is already
			// a directly reachable URL, with no redirect/resolution step needed.
			$play_url = '';
			if (strlen($rec_filename) > 0 && strlen($rec_location) > 2)
				{
				$play_url = $rec_location;
				}

			$report_rows[] = array(
				'lead_id' =>			$rec_lead_id,
				'agent_id' =>			$agent_id,
				'process' =>			$campaign_id,
				'phone_number' =>		$phone_number,
				'start_time' =>			$start_time_display,
				'call_type' =>			$call_type,
				'talk_duration' =>		$talk_duration,
				'recording_status' =>	$recording_status,
				'recording_file' =>		$rec_filename_display,
				'recording_path' =>		$rec_location_display,
				'has_recording' =>		(strlen($rec_filename) > 0),
				'play_url' =>			$play_url
				);
			}

		if ($file_download < 1)
			{
			$start_page = max(1, $page-5);
			$end_page = min($total_pages, $page+5);
			$start_record = $offset + 1;
			$end_record = min($offset + $per_page, $total_records);

			$per_page_select_url = build_recordings_url($PHP_SELF,$campaign,$user_group,$user,$sort_dir,$search_archived_data,$recording_filter,$query_date,$end_date,$query_hour,$end_hour,1,null,null,null);
			$sort_toggle_url = build_recordings_url($PHP_SELF,$campaign,$user_group,$user,(($sort_dir=='asc')?'desc':'asc'),$search_archived_data,$recording_filter,$query_date,$end_date,$query_hour,$end_hour,$page,$per_page,null,null);

			##### CALL RECORDINGS DATA TABLE CARD #####
			echo "<div class=\"user-table-card\">\n";
			echo "<div class=\"user-table-header-bar\">\n";
			echo "<div class=\"d-flex align-items-center gap-2 flex-wrap\">\n";
			echo "<i class=\"bi bi-table text-primary\"></i>\n";
			echo "<strong class=\"table-card-title\">"._QXZ("Call Recordings Log")."</strong>\n";
			echo "</div>\n";
			echo "<div class=\"d-flex align-items-center gap-2 flex-wrap\">\n";
			echo "<div class=\"d-flex align-items-center gap-2 text-muted small\">\n";
			echo "<span>"._QXZ("Rows per page").":</span>\n";
			echo "<select id=\"per_page_select\" onchange=\"window.location.href='".$per_page_select_url."&per_page='+this.value\" class=\"select-per-page-control\">\n";
			foreach (array(10,25,50,100,200,500) as $opt)
				{
				$selected = ($per_page == $opt) ? " selected" : "";
				echo "<option value=\"$opt\"$selected>$opt</option>\n";
				}
			echo "</select>\n";
			echo "</div>\n";
			echo "<div class=\"dropdown\">\n";
			echo "<button type=\"button\" class=\"btn-filter-users dropdown-toggle\" id=\"exportReportDropdown\" data-bs-toggle=\"dropdown\" aria-expanded=\"false\" title=\""._QXZ("Export Report")."\">\n";
			echo "<i class=\"bi bi-download\"></i> <span>"._QXZ("Export")."</span>\n";
			echo "</button>\n";
			echo "<ul class=\"dropdown-menu dropdown-menu-end shadow-sm\" aria-labelledby=\"exportReportDropdown\">\n";
			echo "<li><a class=\"dropdown-item d-flex align-items-center gap-2\" href=\"".$download_link."&export_format=csv\"><i class=\"bi bi-filetype-csv text-primary\"></i> <span>CSV</span></a></li>\n";
			echo "<li><a class=\"dropdown-item d-flex align-items-center gap-2\" href=\"".$download_link."&export_format=xlsx\"><i class=\"bi bi-file-earmark-excel text-success\"></i> <span>Excel (XLSX)</span></a></li>\n";
			echo "<li><a class=\"dropdown-item d-flex align-items-center gap-2\" href=\"".$download_link."&export_format=pdf\"><i class=\"bi bi-file-earmark-pdf text-danger\"></i> <span>PDF</span></a></li>\n";
			echo "</ul>\n";
			echo "</div>\n";
			echo "</div>\n";
			echo "</div>\n";

			echo "<div class=\"table-responsive\">\n";
			echo "<table class=\"custom-table\" id=\"callRecordingsTable\">\n<thead><tr>\n";
			echo "<th class=\"th-call-id\"><span>"._QXZ("Lead ID")."</span></th>\n";
			echo "<th class=\"th-agent-id\"><span>"._QXZ("Agent ID")."</span></th>\n";
			echo "<th class=\"th-process\"><span>"._QXZ("Process")."</span></th>\n";
			echo "<th class=\"th-phone\"><span>"._QXZ("Phone Number")."</span></th>\n";
			echo "<th class=\"th-entry-date sortable-th\" title=\""._QXZ("Click to sort by Start Time")."\"><a href=\"$sort_toggle_url\" class=\"sort-link\">"._QXZ("Start Time")." <i class=\"bi bi-arrow-down-up ms-1 small\"></i></a></th>\n";
			echo "<th class=\"th-call-type\"><span>"._QXZ("Call Type")."</span></th>\n";
			echo "<th class=\"th-duration\"><span>"._QXZ("Talk Duration")."</span></th>\n";
			echo "<th class=\"th-rec-status\"><span>"._QXZ("Recording Status")."</span></th>\n";
			echo "<th class=\"th-rec-file\"><span>"._QXZ("Recording File Name")."</span></th>\n";
			echo "<th class=\"th-rec-path\"><span>"._QXZ("Recording Path")."</span></th>\n";
			echo "</tr></thead>\n<tbody>\n";

			foreach ($report_rows as $r)
				{
				$rec_badge_class = ($r['has_recording']) ? 'badge-status-y' : 'badge-status-n';
				$type_badge_class = (strtoupper($r['call_type']) == 'INBOUND')
					? 'bg-primary-subtle text-primary border border-primary-subtle'
					: 'bg-secondary-subtle text-secondary border border-secondary-subtle';
				echo "<tr>\n";
				echo "<td><span class=\"fw-semibold text-dark\">".htmlspecialchars($r['lead_id'])."</span></td>\n";
				echo "<td><div class=\"d-flex align-items-center gap-1\"><div class=\"user-avatar-box agent-avatar user-avatar-agent-sm\"><i class=\"bi bi-person-fill\"></i></div><span class=\"fw-semibold text-dark\">".htmlspecialchars($r['agent_id'])."</span></div></td>\n";
				echo "<td class=\"text-center\"><span class=\"user-group-tag\"><i class=\"bi bi-geo-alt-fill\"></i> ".htmlspecialchars($r['process'])."</span></td>\n";
				echo "<td><span class=\"fw-semibold text-primary\">".htmlspecialchars($r['phone_number'])."</span></td>\n";
				echo "<td><span class=\"td-entry-date\">".htmlspecialchars($r['start_time'])."</span></td>\n";
				echo "<td class=\"text-center\"><span class=\"badge $type_badge_class fw-semibold badge-call-type\">".htmlspecialchars($r['call_type'])."</span></td>\n";
				echo "<td class=\"text-end\"><span class=\"fw-semibold text-dark font-monospace\">".htmlspecialchars($r['talk_duration'])."</span></td>\n";
				echo "<td class=\"text-center\"><span class=\"$rec_badge_class\"><span class=\"status-dot\"></span>".htmlspecialchars($r['recording_status'])."</span></td>\n";
				if (strlen($r['play_url']) > 0)
					{
					echo "<td><a href=\"#\" onclick=\"openNewWindow('".htmlspecialchars($r['play_url'], ENT_QUOTES)."'); return false;\" class=\"text-primary text-decoration-none fw-semibold d-inline-flex align-items-center gap-1\" title=\""._QXZ("Play Audio")."\"><i class=\"bi bi-play-circle-fill text-success fs-6\"></i> <span>".htmlspecialchars($r['recording_file'])."</span></a></td>\n";
					}
				else
					{
					echo "<td>".htmlspecialchars($r['recording_file'])."</td>\n";
					}
				if ($r['has_recording'])
					{
					echo "<td class=\"text-center\"><button type=\"button\" class=\"btn-copy-path\" onclick=\"copyRecordingPath('".htmlspecialchars(addslashes($r['recording_path']), ENT_QUOTES)."', this)\" title=\""._QXZ("Copy File Path")."\"><i class=\"bi bi-clipboard\"></i> <span>"._QXZ("Copy Path")."</span></button></td>\n";
					}
				else
					{
					echo "<td class=\"text-center text-muted\">-</td>\n";
					}
				echo "</tr>\n";
				}

			echo "</tbody></table>\n";
			echo "</div>\n";

			##### TABLE FOOTER & PAGINATION #####
			echo "<div class=\"user-table-footer-bar\">\n";
			echo "<div>"._QXZ("Showing")." $start_record - $end_record "._QXZ("of")." $total_records "._QXZ("records")."</div>\n";
			echo "<div class=\"user-pagination\">\n";

			if ($page > 1)
				{echo "<a class=\"user-page-btn\" href=\"".build_recordings_url($PHP_SELF,$campaign,$user_group,$user,$sort_dir,$search_archived_data,$recording_filter,$query_date,$end_date,$query_hour,$end_hour,($page-1),$per_page,null,null)."\" title=\""._QXZ("Previous")."\"><i class=\"bi bi-chevron-left\"></i></a>\n";}
			else
				{echo "<a class=\"user-page-btn disabled\" aria-disabled=\"true\" title=\""._QXZ("Previous")."\"><i class=\"bi bi-chevron-left\"></i></a>\n";}

			if ($start_page > 1)
				{
				echo "<a class=\"user-page-btn\" href=\"".build_recordings_url($PHP_SELF,$campaign,$user_group,$user,$sort_dir,$search_archived_data,$recording_filter,$query_date,$end_date,$query_hour,$end_hour,1,$per_page,null,null)."\">1</a>\n";
				if ($start_page > 2) {echo "<span class=\"px-1 text-muted\">&hellip;</span>\n";}
				}

			for ($p=$start_page; $p<=$end_page; $p++)
				{
				if ($p == $page) {echo "<a class=\"user-page-btn active\" href=\"#\">$p</a>\n";}
				else {echo "<a class=\"user-page-btn\" href=\"".build_recordings_url($PHP_SELF,$campaign,$user_group,$user,$sort_dir,$search_archived_data,$recording_filter,$query_date,$end_date,$query_hour,$end_hour,$p,$per_page,null,null)."\">$p</a>\n";}
				}

			if ($end_page < $total_pages)
				{
				if ($end_page < $total_pages-1) {echo "<span class=\"px-1 text-muted\">&hellip;</span>\n";}
				echo "<a class=\"user-page-btn\" href=\"".build_recordings_url($PHP_SELF,$campaign,$user_group,$user,$sort_dir,$search_archived_data,$recording_filter,$query_date,$end_date,$query_hour,$end_hour,$total_pages,$per_page,null,null)."\">$total_pages</a>\n";
				}

			if ($page < $total_pages)
				{echo "<a class=\"user-page-btn\" href=\"".build_recordings_url($PHP_SELF,$campaign,$user_group,$user,$sort_dir,$search_archived_data,$recording_filter,$query_date,$end_date,$query_hour,$end_hour,($page+1),$per_page,null,null)."\" title=\""._QXZ("Next")."\"><i class=\"bi bi-chevron-right\"></i></a>\n";}
			else
				{echo "<a class=\"user-page-btn disabled\" aria-disabled=\"true\" title=\""._QXZ("Next")."\"><i class=\"bi bi-chevron-right\"></i></a>\n";}

			echo "</div>\n";
			echo "</div>\n";
			echo "</div>\n";
			##### END CALL RECORDINGS DATA TABLE CARD #####
			}
		else
			{
			// For download - get all matching records without pagination
			$stmt_all = "SELECT ".$select_cols." FROM ".$calls_union_sql." ORDER BY calls.call_date $sort_dir";
			$rslt_all=mysql_to_mysqli($stmt_all, $link);
			if ($DB) {echo "$stmt_all\n";}

			$export_headers = array(
				_QXZ("Lead ID"),
				_QXZ("Agent ID"),
				_QXZ("Process"),
				_QXZ("Phone Number"),
				_QXZ("Start Time"),
				_QXZ("Call Type"),
				_QXZ("Talk Duration"),
				_QXZ("Recording Status"),
				_QXZ("Recording File Name"),
				_QXZ("Recording Path")
				);

			while ($row_all = mysqli_fetch_row($rslt_all))
				{
				$call_type_a =	$row_all[0];
				$agent_id_a =	$row_all[1];
				$campaign_a =	$row_all[2];
				$phone_a =		$row_all[3];
				$call_date_a =	$row_all[4];
				$length_a =		$row_all[5];
				$rec_file_a =	$row_all[6];
				$rec_loc_a =	$row_all[7];
				$lead_id_a =	$row_all[9];

				if ($LOGadmin_hide_phone_data != '0')
					{
					if (strlen($phone_a) > 0)
						{
						if ($LOGadmin_hide_phone_data == '4_DIGITS') {$phone_a = str_repeat("X",(strlen($phone_a)-4)).substr($phone_a,-4,4);}
						elseif ($LOGadmin_hide_phone_data == '3_DIGITS') {$phone_a = str_repeat("X",(strlen($phone_a)-3)).substr($phone_a,-3,3);}
						elseif ($LOGadmin_hide_phone_data == '2_DIGITS') {$phone_a = str_repeat("X",(strlen($phone_a)-2)).substr($phone_a,-2,2);}
						else {$phone_a = preg_replace("/./",'X',$phone_a);}
						}
					}

				$export_rows[] = array(
					$lead_id_a,
					$agent_id_a,
					$campaign_a,
					$phone_a,
					date('n/j/y G:i:s', strtotime($call_date_a)),
					$call_type_a,
					sec_convert($length_a,'H'),
					((strlen($rec_file_a)>0) ? _QXZ("Available") : _QXZ("Not Available")),
					((strlen($rec_file_a)>0) ? $rec_file_a : '-'),
					((strlen($rec_loc_a)>0) ? $rec_loc_a : '-')
					);
				}
			}
		}
	}

if ($file_download > 0 && count($export_rows) > 0)
	{
	$FILE_TIME = date("Ymd-His");

	header('Expires: 0');
	header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
	header('Pragma: public');
	ob_clean();
	flush();

	if ($export_format == 'xlsx')
		{
		require_once('includes/simple_xlsx_writer.php');
		$XLSXfilename = "CALL_RECORDINGS_$FILE_TIME.xlsx";
		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header("Content-Disposition: attachment; filename=\"$XLSXfilename\"");
		$xlsx_writer = new SimpleXlsxWriter();
		echo $xlsx_writer->build($export_headers, $export_rows);
		}
	elseif ($export_format == 'pdf')
		{
		require_once('includes/simple_pdf_writer.php');
		$PDFfilename = "CALL_RECORDINGS_$FILE_TIME.pdf";
		header('Content-Type: application/pdf');
		header("Content-Disposition: attachment; filename=\"$PDFfilename\"");
		$pdf_writer = new SimplePdfWriter();
		echo $pdf_writer->build($report_display_title, $export_headers, $export_rows);
		}
	else
		{
		$CSVfilename = "CALL_RECORDINGS_$FILE_TIME.csv";
		header('Content-Type: text/csv');
		header("Content-Disposition: attachment; filename=\"$CSVfilename\"");
		$csv_output = fopen('php://output', 'w');
		fputcsv($csv_output, $export_headers);
		foreach ($export_rows as $export_row_to_write) {fputcsv($csv_output, $export_row_to_write);}
		fclose($csv_output);
		}

	if ($db_source == 'S')
		{
		mysqli_close($link);
		$use_slave_server=0;
		$db_source = 'M';
		require("dbconnect_mysqli.php");
		}

	$endMS = microtime();
	$startMSary = explode(" ",$startMS);
	$endMSary = explode(" ",$endMS);
	$runS = ($endMSary[0] - $startMSary[0]);
	$runM = ($endMSary[1] - $startMSary[1]);
	$TOTALrun = ($runS + $runM);

	$stmt="UPDATE vicidial_report_log set run_time='$TOTALrun' where report_log_id='$report_log_id';";
	if ($DB) {echo "|$stmt|\n";}
	$rslt=mysql_to_mysqli($stmt, $link);

	exit;
	}

if ($file_download < 1)
	{
	if ($db_source == 'S')
		{
		mysqli_close($link);
		$use_slave_server=0;
		$db_source = 'M';
		require("dbconnect_mysqli.php");
		}

	$endMS = microtime();
	$startMSary = explode(" ",$startMS);
	$endMSary = explode(" ",$endMS);
	$runS = ($endMSary[0] - $startMSary[0]);
	$runM = ($endMSary[1] - $startMSary[1]);
	$TOTALrun = ($runS + $runM);

	$stmt="UPDATE vicidial_report_log set run_time='$TOTALrun' where report_log_id='$report_log_id';";
	if ($DB) {echo "|$stmt|\n";}
	$rslt=mysql_to_mysqli($stmt, $link);
	?>
				</div>
			</main>
		</div>
	</div>

	<script src="js/main.js"></script>
	<script>
		// Playback opens the recording's real external URL (same path shown in
		// the Recording Path column) directly in a small popup window.
		function openNewWindow(url) {
			window.open(url, "", 'width=620,height=300,scrollbars=yes,menubar=yes,address=yes');
		}

		// Copy Recording Path to Clipboard
		function copyRecordingPath(path, btn) {
			if (!path || path === '-') return;
			if (navigator.clipboard && window.isSecureContext) {
				navigator.clipboard.writeText(path).then(onSuccess).catch(fallbackCopy);
			} else {
				fallbackCopy();
			}
			function onSuccess() {
				if (!btn) return;
				var originalHtml = btn.innerHTML;
				btn.classList.add('copied');
				btn.innerHTML = '<i class="bi bi-check2"></i> <span>Copied!</span>';
				setTimeout(function () {
					btn.classList.remove('copied');
					btn.innerHTML = originalHtml;
				}, 1800);
			}
			function fallbackCopy() {
				var textArea = document.createElement('textarea');
				textArea.value = path;
				textArea.style.position = 'fixed';
				textArea.style.opacity = '0';
				document.body.appendChild(textArea);
				textArea.focus();
				textArea.select();
				try {
					document.execCommand('copy');
					onSuccess();
				} catch (err) {
					console.error('Copy failed', err);
				}
				document.body.removeChild(textArea);
			}
		}
	</script>

	<!-- Local Vendors: Bootstrap 5, jQuery, Moment.js, Select2 & DateRangePicker -->
	<script src="js/bootstrap.bundle.min.js"></script>
	<script src="js/jquery-3.7.1.min.js"></script>
	<script src="js/moment.min.js"></script>
	<script src="js/select2.min.js"></script>
	<script src="js/daterangepicker.min.js"></script>
	<script>
		$(document).ready(function () {
			$('select[multiple]').select2({
				placeholder: "Select options...",
				width: '100%',
				closeOnSelect: false
			});

			// Seed the widget from the REAL filter values this page was just
			// rendered with (not always "today") so a reload after a filter
			// submission shows what was actually submitted.
			var startMoment = moment("<?php echo $query_date ?> <?php echo $query_hour ?>:00", "YYYY-MM-DD HH:mm");
			var endMoment = moment("<?php echo $end_date ?> <?php echo $end_hour ?>:59", "YYYY-MM-DD HH:mm");
			if (!startMoment.isValid()) { startMoment = moment().startOf('day'); }
			if (!endMoment.isValid()) { endMoment = moment().endOf('day'); }

			$('#datetime_range').daterangepicker({
				timePicker: true,
				timePicker24Hour: true,
				timePickerIncrement: 1,
				startDate: startMoment,
				endDate: endMoment,
				maxDate: moment().endOf('day'),
				alwaysShowCalendars: true,
				opens: 'right',
				autoUpdateInput: true,
				ranges: {
					'Today': [moment().startOf('day'), moment().endOf('day')],
					'Yesterday': [moment().subtract(1, 'days').startOf('day'), moment().subtract(1, 'days').endOf('day')],
					'Last 7 Days': [moment().subtract(6, 'days').startOf('day'), moment().endOf('day')],
					'Last 30 Days': [moment().subtract(29, 'days').startOf('day'), moment().endOf('day')],
					'This Month': [moment().startOf('month'), moment().endOf('month')],
					'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
				},
				locale: {
					format: 'YYYY-MM-DD HH:mm',
					separator: ' to ',
					applyLabel: 'Apply Range',
					cancelLabel: 'Cancel',
					fromLabel: 'From',
					toLabel: 'To',
					customRangeLabel: 'Custom Range'
				}
			}, function (start, end) {
				$('#datetime_range').val(start.format('YYYY-MM-DD HH:mm') + ' to ' + end.format('YYYY-MM-DD HH:mm'));
				document.getElementById('query_date').value = start.format('YYYY-MM-DD');
				document.getElementById('query_hour').value = start.format('HH');
				document.getElementById('end_date').value = end.format('YYYY-MM-DD');
				document.getElementById('end_hour').value = end.format('HH');
			});

			$('#datetime_range').val(startMoment.format('YYYY-MM-DD HH:mm') + ' to ' + endMoment.format('YYYY-MM-DD HH:mm'));
		});
	</script>
</body>

</html>
<?php
	}
