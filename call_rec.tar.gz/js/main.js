/**
 * IFTAS Samvad Admin - Common Main JavaScript
 * Handles global UI behaviors:
 *  - Header Live Clock
 *  - Sidebar toggle, collapse, and flyout submenus
 *  - Fullscreen mode handling
 *  - Location filter pills & top mobile dropdown
 *  - User profile dropdowns & global click dismissal
 *  - SOS emergency logout confirmation
 *  - Generic and page filter accordions
 */

(function () {
  'use strict';

  // ==========================================================================
  // 1. LIVE HEADER CLOCK
  // ==========================================================================
  function updateLiveClock() {
    var now = new Date();
    var hours = now.getHours();
    var minutes = now.getMinutes();
    var seconds = now.getSeconds();
    var ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12;
    var strHours = (hours < 10 ? '0' : '') + hours;
    var strMinutes = (minutes < 10 ? '0' : '') + minutes;
    var strSeconds = (seconds < 10 ? '0' : '') + seconds;
    var timeStr = strHours + ':' + strMinutes + ':' + strSeconds + ' ' + ampm;

    var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];
    var dateStr = (now.getDate() < 10 ? '0' : '') + now.getDate() + ' ' + months[now.getMonth()] + ' ' + now.getFullYear();

    var timeEl = document.getElementById('headerLiveTime');
    var dateEl = document.getElementById('headerLiveDate');
    if (timeEl) timeEl.textContent = timeStr;
    if (dateEl) dateEl.textContent = dateStr;
  }

  // ==========================================================================
  // 2. SIDEBAR & NAVIGATION CONTROLLER
  // ==========================================================================
  function toggleSidebar() {
    var app = document.querySelector('.app-container');
    if (!app) return;
    if (window.innerWidth <= 991) {
      app.classList.toggle('sidebar-mobile-open');
    } else {
      var isCollapsed = app.classList.toggle('sidebar-collapsed');
      try {
        localStorage.setItem('sidebar_collapsed', isCollapsed ? 'true' : 'false');
      } catch (e) {}
      document.querySelectorAll('.nav-submenu.flyout-show').forEach(function (el) {
        el.classList.remove('flyout-show');
        el.removeAttribute('style');
      });
    }
  }

  function closeMobileSidebar() {
    var app = document.querySelector('.app-container');
    if (app) app.classList.remove('sidebar-mobile-open');
  }

  function toggleNavSubmenu(el) {
    var navGroup = el.closest('.nav-group');
    if (!navGroup) return;
    var isOpen = navGroup.classList.contains('open');
    document.querySelectorAll('.nav-group.open').forEach(function (group) {
      if (group !== navGroup) group.classList.remove('open');
    });
    navGroup.classList.toggle('open', !isOpen);
  }

  // Restore sidebar state from localStorage on load
  function restoreSidebarState() {
    try {
      if (window.innerWidth > 991 && localStorage.getItem('sidebar_collapsed') === 'true') {
        var app = document.querySelector('.app-container');
        if (app) app.classList.add('sidebar-collapsed');
      }
    } catch (e) {}
  }

  // Sidebar Hover Flyout Submenu Handler (When Collapsed)
  function initSidebarFlyoutMenu() {
    var hideTimeout = null;
    document.querySelectorAll('.sidebar-nav .nav-group').forEach(function (group) {
      var submenu = group.querySelector('.nav-submenu');
      if (!submenu) return;

      group.addEventListener('mouseenter', function () {
        var app = document.querySelector('.app-container');
        if (app && app.classList.contains('sidebar-collapsed')) {
          if (hideTimeout) {
            clearTimeout(hideTimeout);
            hideTimeout = null;
          }
          document.querySelectorAll('.nav-submenu.flyout-show').forEach(function (el) {
            if (el !== submenu) {
              el.classList.remove('flyout-show');
              el.removeAttribute('style');
            }
          });
          var rect = group.getBoundingClientRect();
          submenu.style.visibility = 'hidden';
          submenu.classList.add('flyout-show');
          var submenuHeight = submenu.offsetHeight;
          var windowHeight = window.innerHeight;
          var top = rect.top;

          if (top + submenuHeight > windowHeight - 12) {
            top = Math.max(12, windowHeight - submenuHeight - 12);
          }

          submenu.style.top = top + 'px';
          submenu.style.left = (rect.right + 6) + 'px';
          submenu.style.visibility = 'visible';
        }
      });

      group.addEventListener('mouseleave', function () {
        var app = document.querySelector('.app-container');
        if (app && app.classList.contains('sidebar-collapsed')) {
          hideTimeout = setTimeout(function () {
            submenu.classList.remove('flyout-show');
            submenu.removeAttribute('style');
          }, 150);
        }
      });

      submenu.addEventListener('mouseenter', function () {
        if (hideTimeout) {
          clearTimeout(hideTimeout);
          hideTimeout = null;
        }
      });

      submenu.addEventListener('mouseleave', function () {
        var app = document.querySelector('.app-container');
        if (app && app.classList.contains('sidebar-collapsed')) {
          hideTimeout = setTimeout(function () {
            submenu.classList.remove('flyout-show');
            submenu.removeAttribute('style');
          }, 150);
        }
      });
    });
  }

  // ==========================================================================
  // 3. FULLSCREEN CONTROLLER
  // ==========================================================================
  function toggleFullscreen() {
    if (!document.fullscreenElement && !document.webkitFullscreenElement) {
      var el = document.documentElement;
      if (el.requestFullscreen) el.requestFullscreen().catch(function () {});
      else if (el.webkitRequestFullscreen) el.webkitRequestFullscreen();
    } else {
      if (document.exitFullscreen) document.exitFullscreen().catch(function () {});
      else if (document.webkitExitFullscreen) document.webkitExitFullscreen();
    }
  }

  function handleFullscreenChange() {
    var isFS = !!(document.fullscreenElement || document.webkitFullscreenElement);
    var app = document.querySelector('.app-container');
    if (isFS) {
      document.body.classList.add('is-fullscreen');
      if (app) app.classList.add('is-fullscreen');
    } else {
      document.body.classList.remove('is-fullscreen');
      if (app) app.classList.remove('is-fullscreen');
    }
  }

  document.addEventListener('fullscreenchange', handleFullscreenChange);
  document.addEventListener('webkitfullscreenchange', handleFullscreenChange);

  // ==========================================================================
  // 4. TOPBAR LOCATION FILTERS & PROFILE DROPDOWN
  // ==========================================================================
  function selectLocationPill(locKey, btnEl) {
    document.querySelectorAll('#topLocationFilters .loc-pill-btn').forEach(function (b) {
      b.classList.toggle('active', b.getAttribute('data-loc') === locKey);
    });
    document.querySelectorAll('#topLocMobileDropdown .loc-mobile-item').forEach(function (m) {
      m.classList.toggle('active', m.getAttribute('data-loc') === locKey);
    });

    var mobDropdown = document.getElementById('topLocMobileDropdown');
    if (mobDropdown) mobDropdown.classList.remove('open');

    // If page has a specific onLocationFilterChange handler, call it
    if (typeof window.onLocationFilterChange === 'function') {
      window.onLocationFilterChange(locKey);
    }
  }

  function toggleTopLocationMenu(event) {
    if (event) event.stopPropagation();
    var dropdown = document.getElementById('topLocMobileDropdown');
    if (dropdown) dropdown.classList.toggle('open');
  }

  function toggleUserDropdown(event) {
    if (event) event.stopPropagation();
    var dropdown = event.currentTarget ? event.currentTarget.closest('.user-dropdown') : document.querySelector('.user-dropdown');
    if (dropdown) dropdown.classList.toggle('open');
  }

  // Global dismiss for custom dropdowns on clicking outside
  document.addEventListener('click', function (e) {
    if (!e.target.closest('.user-dropdown')) {
      document.querySelectorAll('.user-dropdown.open').forEach(function (d) {
        d.classList.remove('open');
      });
    }
    if (!e.target.closest('#topLocMobileWrap')) {
      var mob = document.getElementById('topLocMobileDropdown');
      if (mob) mob.classList.remove('open');
    }
  });

  // ==========================================================================
  // 5. FILTER ACCORDION CONTROLLERS
  // ==========================================================================
  function toggleAccordionById(accordionId, textId, chevronId) {
    var accordion = document.getElementById(accordionId);
    if (!accordion) return;
    var isCollapsed = accordion.classList.toggle('collapsed');
    var toggleText = textId ? document.getElementById(textId) : null;
    var chevron = chevronId ? document.getElementById(chevronId) : null;

    if (toggleText) {
      toggleText.textContent = isCollapsed ? 'Show Filters' : 'Hide Filters';
    }
    if (chevron) {
      chevron.className = isCollapsed ? 'bi bi-chevron-down' : 'bi bi-chevron-up';
    }
  }

  function toggleUserFiltersAccordion() {
    toggleAccordionById('userFilterAccordion', 'filterAccordionToggleText', 'filterAccordionChevron');
  }

  function toggleCallFiltersAccordion() {
    toggleAccordionById('callFilterAccordion', 'callFilterAccordionToggleText', 'callFilterAccordionChevron');
  }

  // ==========================================================================
  // 6. SOS EMERGENCY LOGOUT
  // ==========================================================================
  function confirmSOS() {
    window.location.href = '/vicidial/sos_emergency.php';
  }

  // ==========================================================================
  // 7. EXPOSE TO GLOBAL WINDOW SCOPE
  // ==========================================================================
  window.updateLiveClock = updateLiveClock;
  window.toggleSidebar = toggleSidebar;
  window.closeMobileSidebar = closeMobileSidebar;
  window.toggleNavSubmenu = toggleNavSubmenu;
  window.initSidebarFlyoutMenu = initSidebarFlyoutMenu;
  window.toggleFullscreen = toggleFullscreen;
  window.selectLocationPill = selectLocationPill;
  window.toggleTopLocationMenu = toggleTopLocationMenu;
  window.toggleUserDropdown = toggleUserDropdown;
  window.toggleAccordionById = toggleAccordionById;
  window.toggleUserFiltersAccordion = toggleUserFiltersAccordion;
  window.toggleCallFiltersAccordion = toggleCallFiltersAccordion;
  window.confirmSOS = confirmSOS;

  // ==========================================================================
  // 8. AUTO-INITIALIZE ON DOM READY
  // ==========================================================================
  function initApp() {
    restoreSidebarState();
    initSidebarFlyoutMenu();
    updateLiveClock();
    setInterval(updateLiveClock, 1000);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initApp);
  } else {
    initApp();
  }
})();
